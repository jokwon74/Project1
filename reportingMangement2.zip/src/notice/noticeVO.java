package notice;

import java.time.LocalDateTime;

public class noticeVO {
	private String title;
	private String content;
	private long writer_id;
	private LocalDateTime write_Date;

	public noticeVO(String title, String content, long writer_id, LocalDateTime write_Date) {
		super();
		this.title = title;
		this.content = content;
		this.writer_id = writer_id;
		this.write_Date = write_Date;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public long getWriter_id() {
		return writer_id;
	}

	public void setWriter_id(long writer_id) {
		this.writer_id = writer_id;
	}

	public LocalDateTime getWrite_Date() {
		return write_Date;
	}

	public void setWrite_Date(LocalDateTime write_Date) {
		this.write_Date = write_Date;
	}

	@Override
	public String toString() {
		return "noticeVO [title=" + title + ", content=" + content + ", writer_id=" + writer_id + ", write_Date="
				+ write_Date + "]";
	}

}